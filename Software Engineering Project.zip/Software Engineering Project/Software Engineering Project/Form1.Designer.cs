﻿namespace Software_Engineering_Project
{
    partial class Searchclasses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label indexLabel;
            System.Windows.Forms.Label course_NameLabel;
            System.Windows.Forms.Label subjectLabel;
            System.Windows.Forms.Label course_NumberLabel;
            System.Windows.Forms.Label room_NumberLabel;
            System.Windows.Forms.Label instructorLabel;
            System.Windows.Forms.Label daysLabel;
            System.Windows.Forms.Label timeLabel;
            System.Windows.Forms.Label start_DateLabel;
            System.Windows.Forms.Label end_DateLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Searchclasses));
            this.course_DatabaseDataSet1 = new Software_Engineering_Project.Course_DatabaseDataSet();
            this.table1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.table1TableAdapter1 = new Software_Engineering_Project.Course_DatabaseDataSetTableAdapters.Table1TableAdapter();
            this.tableAdapterManager1 = new Software_Engineering_Project.Course_DatabaseDataSetTableAdapters.TableAdapterManager();
            this.table1BindingSource1BindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.table1BindingSource1BindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.indexTextBox1 = new System.Windows.Forms.TextBox();
            this.course_NameTextBox1 = new System.Windows.Forms.TextBox();
            this.subjectTextBox1 = new System.Windows.Forms.TextBox();
            this.course_NumberTextBox1 = new System.Windows.Forms.TextBox();
            this.room_NumberTextBox1 = new System.Windows.Forms.TextBox();
            this.instructorTextBox1 = new System.Windows.Forms.TextBox();
            this.daysTextBox1 = new System.Windows.Forms.TextBox();
            this.timeTextBox1 = new System.Windows.Forms.TextBox();
            this.start_DateDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.end_DateDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            indexLabel = new System.Windows.Forms.Label();
            course_NameLabel = new System.Windows.Forms.Label();
            subjectLabel = new System.Windows.Forms.Label();
            course_NumberLabel = new System.Windows.Forms.Label();
            room_NumberLabel = new System.Windows.Forms.Label();
            instructorLabel = new System.Windows.Forms.Label();
            daysLabel = new System.Windows.Forms.Label();
            timeLabel = new System.Windows.Forms.Label();
            start_DateLabel = new System.Windows.Forms.Label();
            end_DateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.course_DatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource1BindingNavigator)).BeginInit();
            this.table1BindingSource1BindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // indexLabel
            // 
            indexLabel.AutoSize = true;
            indexLabel.Location = new System.Drawing.Point(8, 111);
            indexLabel.Name = "indexLabel";
            indexLabel.Size = new System.Drawing.Size(45, 17);
            indexLabel.TabIndex = 1;
            indexLabel.Text = "Index:";
            // 
            // course_NameLabel
            // 
            course_NameLabel.AutoSize = true;
            course_NameLabel.Location = new System.Drawing.Point(8, 168);
            course_NameLabel.Name = "course_NameLabel";
            course_NameLabel.Size = new System.Drawing.Size(98, 17);
            course_NameLabel.TabIndex = 3;
            course_NameLabel.Text = "Course Name:";
            // 
            // subjectLabel
            // 
            subjectLabel.AutoSize = true;
            subjectLabel.Location = new System.Drawing.Point(423, 124);
            subjectLabel.Name = "subjectLabel";
            subjectLabel.Size = new System.Drawing.Size(59, 17);
            subjectLabel.TabIndex = 5;
            subjectLabel.Text = "Subject:";
            // 
            // course_NumberLabel
            // 
            course_NumberLabel.AutoSize = true;
            course_NumberLabel.Location = new System.Drawing.Point(423, 180);
            course_NumberLabel.Name = "course_NumberLabel";
            course_NumberLabel.Size = new System.Drawing.Size(111, 17);
            course_NumberLabel.TabIndex = 7;
            course_NumberLabel.Text = "Course Number:";
            // 
            // room_NumberLabel
            // 
            room_NumberLabel.AutoSize = true;
            room_NumberLabel.Location = new System.Drawing.Point(423, 230);
            room_NumberLabel.Name = "room_NumberLabel";
            room_NumberLabel.Size = new System.Drawing.Size(103, 17);
            room_NumberLabel.TabIndex = 9;
            room_NumberLabel.Text = "Room Number:";
            // 
            // instructorLabel
            // 
            instructorLabel.AutoSize = true;
            instructorLabel.Location = new System.Drawing.Point(8, 225);
            instructorLabel.Name = "instructorLabel";
            instructorLabel.Size = new System.Drawing.Size(71, 17);
            instructorLabel.TabIndex = 11;
            instructorLabel.Text = "Instructor:";
            // 
            // daysLabel
            // 
            daysLabel.AutoSize = true;
            daysLabel.Location = new System.Drawing.Point(12, 286);
            daysLabel.Name = "daysLabel";
            daysLabel.Size = new System.Drawing.Size(44, 17);
            daysLabel.TabIndex = 13;
            daysLabel.Text = "Days:";
            // 
            // timeLabel
            // 
            timeLabel.AutoSize = true;
            timeLabel.Location = new System.Drawing.Point(423, 286);
            timeLabel.Name = "timeLabel";
            timeLabel.Size = new System.Drawing.Size(43, 17);
            timeLabel.TabIndex = 15;
            timeLabel.Text = "Time:";
            timeLabel.Click += new System.EventHandler(this.timeLabel_Click);
            // 
            // start_DateLabel
            // 
            start_DateLabel.AutoSize = true;
            start_DateLabel.Location = new System.Drawing.Point(12, 345);
            start_DateLabel.Name = "start_DateLabel";
            start_DateLabel.Size = new System.Drawing.Size(76, 17);
            start_DateLabel.TabIndex = 17;
            start_DateLabel.Text = "Start Date:";
            start_DateLabel.Click += new System.EventHandler(this.start_DateLabel_Click);
            // 
            // end_DateLabel
            // 
            end_DateLabel.AutoSize = true;
            end_DateLabel.Location = new System.Drawing.Point(423, 341);
            end_DateLabel.Name = "end_DateLabel";
            end_DateLabel.Size = new System.Drawing.Size(71, 17);
            end_DateLabel.TabIndex = 19;
            end_DateLabel.Text = "End Date:";
            // 
            // course_DatabaseDataSet1
            // 
            this.course_DatabaseDataSet1.DataSetName = "Course_DatabaseDataSet";
            this.course_DatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table1BindingSource1
            // 
            this.table1BindingSource1.DataMember = "Table1";
            this.table1BindingSource1.DataSource = this.course_DatabaseDataSet1;
            // 
            // table1TableAdapter1
            // 
            this.table1TableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Table1TableAdapter = this.table1TableAdapter1;
            this.tableAdapterManager1.UpdateOrder = Software_Engineering_Project.Course_DatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // table1BindingSource1BindingNavigator
            // 
            this.table1BindingSource1BindingNavigator.AddNewItem = this.toolStripButton5;
            this.table1BindingSource1BindingNavigator.BindingSource = this.table1BindingSource1;
            this.table1BindingSource1BindingNavigator.CountItem = this.toolStripLabel1;
            this.table1BindingSource1BindingNavigator.DeleteItem = this.toolStripButton6;
            this.table1BindingSource1BindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.table1BindingSource1BindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator3,
            this.toolStripButton5,
            this.toolStripButton6,
            this.table1BindingSource1BindingNavigatorSaveItem});
            this.table1BindingSource1BindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.table1BindingSource1BindingNavigator.MoveFirstItem = this.toolStripButton1;
            this.table1BindingSource1BindingNavigator.MoveLastItem = this.toolStripButton4;
            this.table1BindingSource1BindingNavigator.MoveNextItem = this.toolStripButton3;
            this.table1BindingSource1BindingNavigator.MovePreviousItem = this.toolStripButton2;
            this.table1BindingSource1BindingNavigator.Name = "table1BindingSource1BindingNavigator";
            this.table1BindingSource1BindingNavigator.PositionItem = this.toolStripTextBox1;
            this.table1BindingSource1BindingNavigator.Size = new System.Drawing.Size(1136, 27);
            this.table1BindingSource1BindingNavigator.TabIndex = 0;
            this.table1BindingSource1BindingNavigator.Text = "bindingNavigator1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton5.Text = "Add new";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(45, 24);
            this.toolStripLabel1.Text = "of {0}";
            this.toolStripLabel1.ToolTipText = "Total number of items";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton6.Text = "Delete";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton1.Text = "Move first";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton2.Text = "Move previous";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Position";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 27);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Current position";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton3.Text = "Move next";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton4.Text = "Move last";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // table1BindingSource1BindingNavigatorSaveItem
            // 
            this.table1BindingSource1BindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.table1BindingSource1BindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("table1BindingSource1BindingNavigatorSaveItem.Image")));
            this.table1BindingSource1BindingNavigatorSaveItem.Name = "table1BindingSource1BindingNavigatorSaveItem";
            this.table1BindingSource1BindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.table1BindingSource1BindingNavigatorSaveItem.Text = "Save Data";
            this.table1BindingSource1BindingNavigatorSaveItem.Click += new System.EventHandler(this.table1BindingSource1BindingNavigatorSaveItem_Click);
            // 
            // indexTextBox1
            // 
            this.indexTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Index", true));
            this.indexTextBox1.Location = new System.Drawing.Point(112, 111);
            this.indexTextBox1.Name = "indexTextBox1";
            this.indexTextBox1.Size = new System.Drawing.Size(100, 22);
            this.indexTextBox1.TabIndex = 2;
            // 
            // course_NameTextBox1
            // 
            this.course_NameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Course Name", true));
            this.course_NameTextBox1.Location = new System.Drawing.Point(112, 165);
            this.course_NameTextBox1.Name = "course_NameTextBox1";
            this.course_NameTextBox1.Size = new System.Drawing.Size(100, 22);
            this.course_NameTextBox1.TabIndex = 4;
            // 
            // subjectTextBox1
            // 
            this.subjectTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Subject", true));
            this.subjectTextBox1.Location = new System.Drawing.Point(566, 124);
            this.subjectTextBox1.Name = "subjectTextBox1";
            this.subjectTextBox1.Size = new System.Drawing.Size(100, 22);
            this.subjectTextBox1.TabIndex = 6;
            // 
            // course_NumberTextBox1
            // 
            this.course_NumberTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Course Number", true));
            this.course_NumberTextBox1.Location = new System.Drawing.Point(566, 177);
            this.course_NumberTextBox1.Name = "course_NumberTextBox1";
            this.course_NumberTextBox1.Size = new System.Drawing.Size(100, 22);
            this.course_NumberTextBox1.TabIndex = 8;
            // 
            // room_NumberTextBox1
            // 
            this.room_NumberTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Room Number", true));
            this.room_NumberTextBox1.Location = new System.Drawing.Point(566, 225);
            this.room_NumberTextBox1.Name = "room_NumberTextBox1";
            this.room_NumberTextBox1.Size = new System.Drawing.Size(100, 22);
            this.room_NumberTextBox1.TabIndex = 10;
            // 
            // instructorTextBox1
            // 
            this.instructorTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Instructor", true));
            this.instructorTextBox1.Location = new System.Drawing.Point(112, 225);
            this.instructorTextBox1.Name = "instructorTextBox1";
            this.instructorTextBox1.Size = new System.Drawing.Size(100, 22);
            this.instructorTextBox1.TabIndex = 12;
            // 
            // daysTextBox1
            // 
            this.daysTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Days", true));
            this.daysTextBox1.Location = new System.Drawing.Point(112, 286);
            this.daysTextBox1.Name = "daysTextBox1";
            this.daysTextBox1.Size = new System.Drawing.Size(100, 22);
            this.daysTextBox1.TabIndex = 14;
            // 
            // timeTextBox1
            // 
            this.timeTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.table1BindingSource1, "Time", true));
            this.timeTextBox1.Location = new System.Drawing.Point(472, 283);
            this.timeTextBox1.Name = "timeTextBox1";
            this.timeTextBox1.Size = new System.Drawing.Size(204, 22);
            this.timeTextBox1.TabIndex = 16;
            this.timeTextBox1.TextChanged += new System.EventHandler(this.timeTextBox1_TextChanged);
            // 
            // start_DateDateTimePicker1
            // 
            this.start_DateDateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.table1BindingSource1, "Start Date", true));
            this.start_DateDateTimePicker1.Location = new System.Drawing.Point(112, 341);
            this.start_DateDateTimePicker1.Name = "start_DateDateTimePicker1";
            this.start_DateDateTimePicker1.Size = new System.Drawing.Size(182, 22);
            this.start_DateDateTimePicker1.TabIndex = 18;
            this.start_DateDateTimePicker1.ValueChanged += new System.EventHandler(this.start_DateDateTimePicker1_ValueChanged);
            // 
            // end_DateDateTimePicker1
            // 
            this.end_DateDateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.table1BindingSource1, "End Date", true));
            this.end_DateDateTimePicker1.Location = new System.Drawing.Point(500, 337);
            this.end_DateDateTimePicker1.Name = "end_DateDateTimePicker1";
            this.end_DateDateTimePicker1.Size = new System.Drawing.Size(176, 22);
            this.end_DateDateTimePicker1.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(355, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 32);
            this.label2.TabIndex = 21;
            this.label2.Text = "Class Management";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 388);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(121, 388);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 23;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Searchclasses
            // 
            this.ClientSize = new System.Drawing.Size(1136, 433);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(end_DateLabel);
            this.Controls.Add(this.end_DateDateTimePicker1);
            this.Controls.Add(start_DateLabel);
            this.Controls.Add(this.start_DateDateTimePicker1);
            this.Controls.Add(timeLabel);
            this.Controls.Add(this.timeTextBox1);
            this.Controls.Add(daysLabel);
            this.Controls.Add(this.daysTextBox1);
            this.Controls.Add(instructorLabel);
            this.Controls.Add(this.instructorTextBox1);
            this.Controls.Add(room_NumberLabel);
            this.Controls.Add(this.room_NumberTextBox1);
            this.Controls.Add(course_NumberLabel);
            this.Controls.Add(this.course_NumberTextBox1);
            this.Controls.Add(subjectLabel);
            this.Controls.Add(this.subjectTextBox1);
            this.Controls.Add(course_NameLabel);
            this.Controls.Add(this.course_NameTextBox1);
            this.Controls.Add(indexLabel);
            this.Controls.Add(this.indexTextBox1);
            this.Controls.Add(this.table1BindingSource1BindingNavigator);
            this.Name = "Searchclasses";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Searchclasses_Load);
            ((System.ComponentModel.ISupportInitialize)(this.course_DatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource1BindingNavigator)).EndInit();
            this.table1BindingSource1BindingNavigator.ResumeLayout(false);
            this.table1BindingSource1BindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Course_DatabaseDataSet course_DatabaseDataSet;
        private System.Windows.Forms.BindingSource table1BindingSource;
        private Course_DatabaseDataSetTableAdapters.Table1TableAdapter table1TableAdapter;
        private Course_DatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator table1BindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton table1BindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox indexTextBox;
        private System.Windows.Forms.TextBox course_NameTextBox;
        private System.Windows.Forms.TextBox subjectTextBox;
        private System.Windows.Forms.TextBox course_NumberTextBox;
        private System.Windows.Forms.TextBox room_NumberTextBox;
        private System.Windows.Forms.TextBox instructorTextBox;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.TextBox timeTextBox;
        private System.Windows.Forms.DateTimePicker start_DateDateTimePicker;
        private System.Windows.Forms.DateTimePicker end_DateDateTimePicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddClass;
        private System.Windows.Forms.Button button2;
        private Course_DatabaseDataSet course_DatabaseDataSet1;
        private System.Windows.Forms.BindingSource table1BindingSource1;
        private Course_DatabaseDataSetTableAdapters.Table1TableAdapter table1TableAdapter1;
        private Course_DatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.BindingNavigator table1BindingSource1BindingNavigator;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton table1BindingSource1BindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox indexTextBox1;
        private System.Windows.Forms.TextBox course_NameTextBox1;
        private System.Windows.Forms.TextBox subjectTextBox1;
        private System.Windows.Forms.TextBox course_NumberTextBox1;
        private System.Windows.Forms.TextBox room_NumberTextBox1;
        private System.Windows.Forms.TextBox instructorTextBox1;
        private System.Windows.Forms.TextBox daysTextBox1;
        private System.Windows.Forms.TextBox timeTextBox1;
        private System.Windows.Forms.DateTimePicker start_DateDateTimePicker1;
        private System.Windows.Forms.DateTimePicker end_DateDateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
    }
}

