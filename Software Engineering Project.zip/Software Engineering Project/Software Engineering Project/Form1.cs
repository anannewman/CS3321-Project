﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Engineering_Project
{
    public partial class Searchclasses : Form
    {
        public Searchclasses()
        {
            InitializeComponent();
        }

        private void table1BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.table1BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.course_DatabaseDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'course_DatabaseDataSet.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter.Fill(this.course_DatabaseDataSet.Table1);

        }

        private void course_NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void course_NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void course_NumberLabel_Click(object sender, EventArgs e)
        {

        }

        private void instructorLabel_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void indexTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void table1BindingSource1BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.table1BindingSource1.EndEdit();
            this.tableAdapterManager1.UpdateAll(this.course_DatabaseDataSet1);

        }

        private void Searchclasses_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'course_DatabaseDataSet1.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter1.Fill(this.course_DatabaseDataSet1.Table1);

        }

        private void timeTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timeLabel_Click(object sender, EventArgs e)
        {

        }

        private void start_DateLabel_Click(object sender, EventArgs e)
        {

        }

        private void start_DateDateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
   }
}
